//
//  CustomTabBarController.swift
//  GiveLife
//
//  Created by JENIL BHADJA on 28/03/22.
//

import Foundation
import UIKit

class CustomTabBarController: UITableViewController{
    
    @IBInspectable var intialIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        selectedIndex = intialIndex
    }
    
}
