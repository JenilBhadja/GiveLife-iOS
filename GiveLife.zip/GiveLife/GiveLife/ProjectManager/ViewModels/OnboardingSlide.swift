//
//  OnboardingSlide.swift
//  GiveLife
//
//  Created by JENIL BHADJA on 01/09/21.
//

import UIKit

struct OnboardingSlide{
    let title: String
    let description:String
    let image:UIImage
}
